const express = require("express");
const mysql = require("mysql2");
const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieparser = require("cookie-parser");
const app = express();
const bodyparser = require("body-parser");
const util = require('util');

app.use(express.static("public"));


app.set("view engine","ejs");
app.use(cookieparser());
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));
const con = mysql.createConnection ({
    host:"localhost",
    user:"root",
    password:"root",
    database:"registration"
});

con.connect((err)=>{
    if(err) throw err;
    console.log("success");
})


const sendquery = util.promisify(con.query.bind(con));

app.get("/registration",(req,res)=>{
    res.render("registration.ejs");
});

app.post("/register",async (req,res)=>{
    console.log(req.body);
    var studentData = req.body;
    let Encpassword = await bcryptjs.hash(studentData.password,10);

console.log(Encpassword);
let insertquery = sendquery(`insert into registration(name,email,password) values('${studentData.name}','${studentData.email}','${Encpassword}')`);
 res.redirect("/login");

});

app.get("/login",(req,res)=>{
res.render("login.ejs");
});

app.post("/login", async (req,res)=>{

console.log(req.body);
let checkemail = await sendquery(`select * from registration where email = '${req.body.email}'`);
console.log(checkemail);


if(checkemail == ""){
   return res.json("Email id not found");
}

 let checkpass = await bcryptjs.compare(req.body.password,checkemail[0].password);
console.log("checkpass ::::::::",checkpass);
 if(checkpass){
  let token=   jwt.sign(checkemail[0],"rajeshparmar");
  console.log("token  :::",token);
res.cookie("cookie",token);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
  res.redirect("/index");
 }else{
    res.json("envalid password");
 }

});

app.get("/index",(req,res)=>{
let getcookie = req.cookies;
console.log("getcookie",getcookie);

if(!getcookie.cookie){
    return res.redirect("/registration");
}
let checktoken = jwt.verify(getcookie.cookie,"rajeshparmar");
console.log("checktoken",checktoken);
    res.render("index.ejs",{name:checktoken.name});
});

app.get("/logout",(req,res)=>{
    res.clearCookie("cookie");
    res.redirect("/registration");

})


app.listen(7676);